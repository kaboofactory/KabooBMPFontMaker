﻿==============================
  BMP Font Maker
==============================

【 ソフト名 】 BMP Font Maker
【 製 作 者 】 カブーファクトリー
【  種  別  】 フリーウェア
【 開発環境 】 Microsoft Visual Studio Community 2015
【 動作環境 】 .NET Framework 4 Client Profile
【バージョン】 1.0.0.0
【最終更新日】 2017/02/26

【 ウェブ 】 https://twitter.com/kaboo_factory
【 E-mail 】 上記ツイッターよりご連絡ください

---------- ----------
◇ 概要 ◇

 いわゆるビットマップフォントを生成するジェネレータです

◇ 動作条件 ◇

 .NET Framework 4 Client Profile が動作する環境

 Windows 8 以降なら何もインストールしなくても動くと思われる

◇ ファイル構成 ◇

 BMPFontMaker.exe …　本体
 README.txt …　本ファイル

◇ インストール ◇

 .NET Framework 4 Client Profile がインストールされていることを確認し、
 BMPFontMaker.exeを実行してください

 インストールされていない場合は、自分で調べてインストールしてください。

◇ アンインストール ◇

 梱包されているファイル一式を削除してください。

◇ つかいかた ◇

 設定の保存 : ファイル(F) → 名前を付けて保存(A)
 設定の読み込み : ファイル(F) → 開く(O)
 ビットマップ画像を出力する : ファイル(F) → 出力(E)
 使用する文字の指定 : 文字セット指定(M)

 後は色々試してみよう

◇ 免責・転載・ライセンス ◇

This software is released under the MIT License, see LICENSE.txt.

◇ 既知のバグ ◇

・フォントによっては正常にレンダリングできない場合があります(フォントの不具合の場合もあります)
・カーニング情報を出力できません(GetKerningPairsのちゃんとした使い方がわからない)
・汚いソース(見逃して)

◇ 履歴 ◇

 v1.0.0.0 はぁ～ 生まれた生まれた。(動物番長的な意味で)
